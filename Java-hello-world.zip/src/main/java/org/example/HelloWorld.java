package org.example;

public class HelloWorld {
    public static void main(String[] argvs) {
        System.out.println("Hello World !");
    }
}
